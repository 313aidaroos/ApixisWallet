# Apixis Wallet MVP

**One balance across every Apixis product.**

Apixis Wallet is the shared commerce layer for Renoxis, Socixis, Lyrixis, Recovra, Deduxis, Rawixis, Halaxis, Apixis Command and future Apixis products. Customers buy Xis Points (XP), keep one universal balance, and spend it on subscriptions, usage, upgrades and personalization.

## What works in this MVP

- Responsive wallet dashboard and point-pack storefront.
- Cross-platform product catalog and preview activation.
- Purchased, bonus and reserved XP presentation.
- Transaction history and renewal insight.
- Stripe Checkout route with signed-webhook skeleton.
- Supabase double-entry ledger schema, RLS and entitlements.
- Clear separation between closed-loop XP and future APX token.

The dashboard runs with demo data immediately. Real authentication, persisted balances and actual XP fulfillment require completing the production checklist in `docs/BUILD_AND_LAUNCH.md`.

## Quick start

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`.

## Verify

```bash
npm run lint
npm run typecheck
npm run build
```

## Non-negotiable rules

1. Never modify wallet balance directly. Add balanced ledger entries.
2. Use Stripe webhook event IDs as idempotency keys.
3. Keep service and Stripe restricted keys server-only.
4. XP is non-transferable, non-withdrawable platform credit at launch.
5. APX is a separate future digital asset and never an automatic XP conversion.
6. Show `100 XP = $1` alongside prices.
7. Paid XP does not expire; promotional XP may expire only with disclosure.
8. Every charge must be shown before approval and recorded in the ledger.

Read `VISION.md`, `docs/BUILD_AND_LAUNCH.md`, and `GROK_MASTER_PROMPT.md` before continuing development.
